<?php

include_once("news.html");

?>